import telebot
from telebot import types
import os
import time
import pyautogui
import psutil
import webbrowser
import tkinter as tk
from tkinter import messagebox
import threading

token = "8386295162:AAGxUB65-vKB6eHQU9ga_elYk5ENOepQOH8"
bot = telebot.TeleBot(token)

@bot.message_handler(commands=['start'])
def start(message):
    markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
    btn1 = types.KeyboardButton("🧾 скрипты")
    btn2 = types.KeyboardButton("🔌 питание")
    btn3 = types.KeyboardButton("🔊 звук")
    btn4 = types.KeyboardButton("🌆 скрин")
    btn5 = types.KeyboardButton("📄 статы")
    markup.add(btn1, btn2, btn3)
    markup.add(btn4, btn5)
    bot.send_message(message.chat.id, "здарова", reply_markup=markup)


@bot.message_handler(func=lambda message: True)
def handle_message(message):
    text = message.text.lower()

    # --- скрипты ---
    if text == "🧾 скрипты" or text == "скрипты":
        markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
        btn1 = types.KeyboardButton("🗨️ мсг бокс")
        btn2 = types.KeyboardButton("🌐 сайт")
        btn3 = types.KeyboardButton("🧾 запустить")
        btn4 = types.KeyboardButton("💀 убить процесс")
        btn6 = types.KeyboardButton("⌨️ пайавтогуи")
        btn5 = types.KeyboardButton("⬅️ назад")
        markup.add(btn1, btn2, btn3)
        markup.add(btn4, btn6)
        markup.add(btn5)
        bot.send_message(message.chat.id, "ок", reply_markup=markup)
    
    elif text == '⌨️ пайавтогуи':
        markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
        escb = types.KeyboardButton("esc")
        wb = types.KeyboardButton("w")
        ab = types.KeyboardButton("a")
        sb = types.KeyboardButton("s")
        db = types.KeyboardButton("d")
        eb = types.KeyboardButton("e")
        leftb = types.KeyboardButton("лкм")
        rightb = types.KeyboardButton("пкм")
        btn5 = types.KeyboardButton("⬅️ назад")
        markup.add(escb, wb, eb)
        markup.add(ab, sb, db)
        markup.add(leftb, rightb)
        markup.add(btn5)
        bot.send_message(message.chat.id, "нажимай кнопки для управления", reply_markup=markup)

    elif text in ["w", "a", "s", "d", "e", "esc"]:
        pyautogui.press(text)
        bot.send_message(message.chat.id, f"нажал клавишу {text.upper()}")

    elif text == "лкм":
        pyautogui.click()
        bot.send_message(message.chat.id, "клик левой кнопкой мыши")

    elif text == "пкм":
        pyautogui.click(button="right")
        bot.send_message(message.chat.id, "клик правой кнопкой мыши")

    elif text == "🌐 сайт":
        bot.send_message(message.chat.id, "введи адрес сайта (например: https://google.com)")
        bot.register_next_step_handler(message, open_site)

    elif text == "🗨️ мсг бокс":
        markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
        btn1 = types.KeyboardButton("ℹ️ информация")
        btn2 = types.KeyboardButton("⚠️ предупреждение")
        btn3 = types.KeyboardButton("❌ ошибка")
        btn4 = types.KeyboardButton("❓ вопрос")
        btn5 = types.KeyboardButton("⬅️ отмена")
        markup.add(btn1, btn2)
        markup.add(btn3, btn4)
        markup.add(btn5)
        bot.send_message(message.chat.id, "выбери тип окна", reply_markup=markup)
        bot.register_next_step_handler(message, choose_msgbox_type)

    elif text == "🧾 запустить":
        bot.send_message(message.chat.id, "введи команду или путь к скрипту для запуска")
        bot.register_next_step_handler(message, run_script)

    elif text == "💀 убить процесс":
        bot.send_message(message.chat.id, "введи имя процесса (например: chrome.exe)")
        bot.register_next_step_handler(message, kill_process)

    # --- питание ---
    elif "🔌 питание" in text:
        markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
        btn1 = types.KeyboardButton("🔴 выключить")
        btn2 = types.KeyboardButton("🔄 рестарт")
        btn3 = types.KeyboardButton("🌙 сон")
        btn4 = types.KeyboardButton("⏱️ таймер")
        btn5 = types.KeyboardButton("⬅️ назад")
        markup.add(btn1, btn2, btn3)
        markup.add(btn4)
        markup.add(btn5)
        bot.send_message(message.chat.id, "ок", reply_markup=markup)

    elif text == "🔴 выключить":
        os.system("shutdown /s /t 1")
        bot.send_message(message.chat.id, "выключаю пк")

    elif text == "🔄 рестарт":
        os.system("shutdown /r /t 1")
        bot.send_message(message.chat.id, "перезагружаю пк")

    elif text == "🌙 сон":
        os.system("rundll32.exe powrprof.dll,SetSuspendState 0,1,0")
        bot.send_message(message.chat.id, "усыпляю пк")

    elif text == "⏱️ таймер":
        bot.send_message(message.chat.id, "через сколько минут выключить пк? (введи число)")
        bot.register_next_step_handler(message, set_timer)

    # --- звук ---
    elif "🔊 звук" in text:
        bot.send_message(message.chat.id, "введи громкость (от 0 до 100)")
        bot.register_next_step_handler(message, set_volume)

    # --- скрин ---
    elif "🌆 скрин" in text:
        screenshot = pyautogui.screenshot()
        screenshot.save("screenshot.png")
        with open("screenshot.png", "rb") as photo:
            bot.send_document(message.chat.id, photo)
        os.remove("screenshot.png")

    # --- статы ---
    elif "📄 статы" in text:
        cpu = psutil.cpu_percent()
        mem = psutil.virtual_memory().percent
        memc = psutil.virtual_memory().used
        mema = psutil.virtual_memory().total
        mhz = psutil.cpu_freq().current
        btime = psutil.boot_time()
        bot.send_message(message.chat.id, f"кпу: {cpu}% ({mhz} мгц)\nрам: {mem}% ({int((mema - memc) / 1024 / 1024)} / {int(mema / 1024 / 1024)} мб)\nбут тайм: {btime}")

    # --- назад ---
    elif "⬅️ назад" in text:
        start(message)


# функции

def choose_msgbox_type(message):
    text = message.text.lower()
    types_map = {
        "ℹ️ информация": "info",
        "⚠️ предупреждение": "warning",
        "❌ ошибка": "error",
        "❓ вопрос": "question"
    }
    if text not in types_map and text != "⬅️ отмена":
        bot.send_message(message.chat.id, "выбери из кнопок")
        return
    if text == "⬅️ отмена":
        start(message)
        return

    msg_type = types_map[text]
    bot.send_message(message.chat.id, "введи текст для msgbox")
    bot.register_next_step_handler(message, lambda m: msg_box(m, msg_type))


def msg_box(message, msg_type):
    text = message.text

    def show_msg():
        root = tk.Tk()
        root.withdraw()
        if msg_type == "info":
            messagebox.showinfo(f'от @{message.from_user.username}', text)
        elif msg_type == "warning":
            messagebox.showwarning(f'от @{message.from_user.username}', text)
        elif msg_type == "error":
            messagebox.showerror(f'от @{message.from_user.username}', text)
        elif msg_type == "question":
            messagebox.askquestion(f'от @{message.from_user.username}', text)
        root.destroy()
        bot.send_message(message.chat.id, f"сообщение было закрыто ({text})")

    threading.Thread(target=show_msg, daemon=True).start()
    bot.send_message(message.chat.id, f"показал сообщение ({msg_type}): {text}")


def run_script(message):
    cmd = message.text
    try:
        os.startfile(cmd)
        bot.send_message(message.chat.id, f"запускаю: {cmd}")
    except Exception as e:
        bot.send_message(message.chat.id, f"ошибка: {e}")


def kill_process(message):
    name = message.text.strip()
    try:
        os.system(f"taskkill /f /im {name}")
        bot.send_message(message.chat.id, f"убил процесс: {name}")
    except Exception as e:
        bot.send_message(message.chat.id, f"ошибка: {e}")


def set_timer(message):
    try:
        mins = int(message.text)
        bot.send_message(message.chat.id, f"ок, выключу пк через {mins} минут")
        time.sleep(mins * 60)
        os.system("shutdown /s /t 1")
    except ValueError:
        bot.send_message(message.chat.id, "введи число")


def set_volume(message):
    try:
        vol = int(message.text)
        if 0 <= vol <= 100:
            os.system(f"nircmd.exe setsysvolume {int(vol * 655.35)}")
            bot.send_message(message.chat.id, f"установил громкость {vol}%")
        else:
            bot.send_message(message.chat.id, "введи число от 0 до 100")
    except ValueError:
        bot.send_message(message.chat.id, "введи число")


def open_site(message):
    url = message.text.strip()
    if not url.startswith("http"):
        url = "https://" + url
    try:
        webbrowser.open(url)
        bot.send_message(message.chat.id, f"открываю сайт: {url}")
    except Exception as e:
        bot.send_message(message.chat.id, f"ошибка: {e}")


print("бот запущен...")
bot.infinity_polling()
